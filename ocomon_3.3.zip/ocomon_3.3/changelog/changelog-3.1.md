# Changelog OcoMon a partir da versão 3.0

## Modificações gerais


+ Adicionado o arquivo de idiomas em Inglês
    
    
## Módulo de Ocorrências

+ Agora é possível isolar a visibilidade entre áreas de atendimento. Isso é válido para o Filtro avançado, Relatórios e Painel de Controle.

+ Ajustes na impressão de chamados
    

## Módulo de Inventário

+ Ajustes nos termos de responsabilidade
    
    
## Módulo de Administração

+ Adicionada a opção "Visibilidade entre áreas".
    - Ativando essa opção, usuários operadores terão retorno apenas de chamados vinculados às suas próprias áreas quando utilizarem o Filtro avançado, Relatórios e Painel de Controle.


## Bugs corrigidos

+ Algumas entradas no arquivo de idiomas estavam faltando.

---


### Fique por dentro

+ Site oficial: [https://ocomonphp.sourceforge.io/](https://ocomonphp.sourceforge.io/)

+ Instruções para instalação ou atualização: [https://ocomonphp.sourceforge.io/instalacao/](https://ocomonphp.sourceforge.io/instalacao/)

+ Requisitos: [https://ocomonphp.sourceforge.io/versoes-requisitos/](https://ocomonphp.sourceforge.io/versoes-requisitos/)

+ Twitter: [https://twitter.com/OcomonOficial](https://twitter.com/OcomonOficial)

+ Canal no Youtube: [https://www.youtube.com/channel/UCFikgr9Xk2bE__snw1_RYtQ](https://www.youtube.com/channel/UCFikgr9Xk2bE__snw1_RYtQ)


### Entre em contato:
+ E-mail: [ocomon.oficial@gmail.com](ocomon.oficial@gmail.com)
