<?php 
print "<html><head><title>Help do Sistema Ocomon</title>";

	print "<style type=\"text/css\"><!--";
	print "body.corpo {background-color:#F6F6F6; font-family:helvetica;}";
	print "p{font-size:12px; text-align:justify; }";
	print "table.pop {width:100%; margin-left:auto; margin-right: auto; text-align:left;
		border: 0px; border-spacing:1 ;background-color:#f6f6f6; padding-top:10px; }";
	print "tr.linha {font-family:helvetica; font-size:10px; line-height:1em; }";
	print "--></STYLE>";
	print "</head><body class='corpo'>";

	print "<br><br><br><br><br><br><br><br><br><br>";
	print "OCOMON: ARQUIVO DE HELP AINDA EM CONSTRUÇÃO. AGUARDE!";



print "</body></html>";

?>