<?php 
print "<html><head><title>OcoMon Help: Tela principal</title>";

	print "<style type=\"text/css\"><!--";
	print "body.corpo {background-color:#F6F6F6; font-family:helvetica;}";
	print "p{font-size:12px; text-align:justify; }";
	print "table.pop {width:100%; margin-left:auto; margin-right: auto; text-align:left;
		border: 0px; border-spacing:1 ;background-color:#f6f6f6; padding-top:10px; }";
	print "tr.linha {font-family:helvetica; font-size:10px; line-height:1em; }";
	print "--></STYLE>";
	print "</head><body class='corpo'>";

	print "AJUDA DO OCOMON";

	print "<p><b>Tela principal de chamados:</b></p>";
		print "<ul>";
		print "<li><p>Nesta tela você tem acesso a todas ocorrências em aberto para as áreas que você faz parte. ".
				"Além disso, você também gerencia os chamados que estão vinculados a você.</p></li>";
		print "</ul>";
	print "<p><b>Informações visíveis nessa tela:</b></p>";
		print "<ul>";
		print "<li><p>Mural de avisos: aqui ficam visíveis os recados/avisos encaminhados para as áreas que você pertence.</p></li>";
		print "<li><p>Ocorrências vinculadas a você: Nessa tela você visualiza todas as ocorrências que estão vinculadas a você, sejam ".
				"em atendimento ou apenas encaminhadas.</p></li>";
		print "</ul>";


print "</body></html>";

?>